require("dotenv").config();
const express=require("express"),helmet=require("helmet"),morgan=require("morgan"),crypto=require("crypto"),path=require("path");
const app=express(),PORT=process.env.PORT||3000,SECRET=process.env.WEBHOOK_SECRET||"local-demo-secret";
app.use(helmet({contentSecurityPolicy:false}));app.use(morgan("dev"));app.use(express.json({limit:"1mb"}));app.use(express.static(path.join(__dirname,"public")));
const merchants=[
{id:"mer_demo_01",name:"Kedai Nusantara",email:"merchant@example.test",status:"demo"},
{id:"mer_demo_02",name:"Studio Pixel",email:"pixel@example.test",status:"pending_review"}
];
const transactions=[
{id:"txn_demo_1001",merchantId:"mer_demo_01",orderId:"ORD-1001",amount:125000,status:"paid",method:"QRIS (simulasi)",createdAt:new Date(Date.now()-3600000).toISOString()},
{id:"txn_demo_1002",merchantId:"mer_demo_02",orderId:"ORD-1002",amount:75000,status:"pending",method:"QRIS (simulasi)",createdAt:new Date(Date.now()-1800000).toISOString()},
{id:"txn_demo_1003",merchantId:"mer_demo_01",orderId:"ORD-1003",amount:250000,status:"paid",method:"QRIS (simulasi)",createdAt:new Date(Date.now()-86400000).toISOString()}
];
app.get("/api/health",(_,r)=>r.json({ok:true,mode:process.env.PAYMENT_PROVIDER||"mock"}));
app.get("/api/overview",(_,r)=>{const paid=transactions.filter(t=>t.status==="paid");r.json({stats:{totalVolume:paid.reduce((s,t)=>s+t.amount,0),paidCount:paid.length,pendingCount:transactions.filter(t=>t.status==="pending").length,merchantCount:merchants.length},transactions:[...transactions].sort((a,b)=>b.createdAt.localeCompare(a.createdAt)),merchants});});
app.get("/api/transactions",(_,r)=>r.json({transactions}));
app.get("/api/merchants",(_,r)=>r.json({merchants}));
app.post("/api/payment-intents",(q,r)=>{const {merchantId,orderId,amount,description}=q.body||{};if(!merchants.some(m=>m.id===merchantId))return r.status(400).json({error:"merchantId tidak valid"});if(!Number.isSafeInteger(amount)||amount<1000||amount>100000000)return r.status(400).json({error:"Nominal harus Rp1.000–Rp100.000.000"});if(typeof orderId!=="string"||orderId.trim().length<3||orderId.length>80)return r.status(400).json({error:"orderId wajib 3–80 karakter"});const tx={id:"txn_"+crypto.randomBytes(6).toString("hex"),merchantId,orderId:orderId.trim(),description:String(description||"Tagihan baru").slice(0,120),amount,status:"pending",method:"QRIS (simulasi)",createdAt:new Date().toISOString()};transactions.unshift(tx);r.status(201).json({transaction:tx,mode:"simulation",message:"Ini simulasi, bukan QRIS asli."});});
app.post("/api/demo/transactions/:id/mark-paid",(q,r)=>{const tx=transactions.find(t=>t.id===q.params.id);if(!tx)return r.status(404).json({error:"Transaksi tidak ditemukan"});tx.status="paid";tx.paidAt=new Date().toISOString();r.json({transaction:tx,mode:"simulation"});});
app.post("/api/webhooks/provider",express.raw({type:"application/json"}),(q,r)=>{const sig=String(q.header("x-pinjiipay-signature")||"");const expected=crypto.createHmac("sha256",SECRET).update(q.body).digest("hex");let a,b;try{a=Buffer.from(sig,"hex");b=Buffer.from(expected,"hex")}catch{return r.status(401).json({error:"Signature tidak valid"})}if(!sig||a.length!==b.length||!crypto.timingSafeEqual(a,b))return r.status(401).json({error:"Signature tidak valid"});let event;try{event=JSON.parse(q.body.toString())}catch{return r.status(400).json({error:"JSON tidak valid"})}const tx=transactions.find(t=>t.id===event.transactionId||t.orderId===event.orderId);if(!tx)return r.status(404).json({error:"Transaksi tidak ditemukan"});if(event.status==="PAID"){tx.status="paid";tx.paidAt=new Date().toISOString()}r.json({received:true});});
app.get("*",(_,r)=>r.sendFile(path.join(__dirname,"public","index.html")));
app.listen(PORT,()=>console.log(`PINJII PAY: http://localhost:${PORT}`));
