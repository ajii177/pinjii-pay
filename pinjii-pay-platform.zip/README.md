# PINJII PAY — platform starter

Website responsif untuk dashboard admin/penjual dan fondasi API backend multi-merchant.

## Menjalankan lokal
Butuh Node.js 18+.
```bash
cp .env.example .env
npm install
npm start
```
Buka http://localhost:3000

## Yang sudah tersedia
- Dashboard admin: ringkasan, transaksi, penjual, QRIS, pembagian dana, laporan, pengaturan.
- Endpoint API demo untuk overview, transaksi, merchant, payment intent, dan webhook.
- Form membuat tagihan demo dan aksi simulasi status lunas.
- Kunci provider disiapkan melalui environment server, bukan JavaScript frontend.

## Batasan penting
**Ini belum siap production dan tidak membuat QRIS sungguhan.** Data saat ini tersimpan di memori dan hilang saat server restart. Belum ada login, otorisasi role, isolasi data penjual, database permanen, integrasi provider, split settlement sungguhan, rate limiting, idempotensi, atau audit lengkap. Jangan gunakan untuk dana/data pelanggan nyata.

Untuk transaksi live, pilih provider berizin yang secara eksplisit menyetujui model platform/marketplace, QRIS dinamis, onboarding sub-merchant, dan split settlement. Ikuti seluruh proses onboarding/verifikasi provider; jangan mencoba melewatinya.

## Endpoint starter
- `GET /api/health`
- `GET /api/overview`
- `GET /api/transactions`
- `GET /api/merchants`
- `POST /api/payment-intents` — simulasi
- `POST /api/demo/transactions/:id/mark-paid` — simulasi saja
- `POST /api/webhooks/provider` — contoh HMAC; wajib disesuaikan dengan spesifikasi resmi provider

## Checklist sebelum production
1. Implementasikan login aman dan role admin/penjual.
2. Gunakan PostgreSQL + migrations dan indeks unik untuk referensi transaksi/event.
3. Pastikan setiap endpoint memverifikasi kepemilikan merchant; jangan percaya merchantId dari browser.
4. Terapkan validasi input, rate limit, CSRF jika memakai cookie session, audit log, dan manajemen rahasia.
5. Buat adapter provider di server dan simpan API secret hanya pada environment/server secret manager.
6. Ikuti verifikasi webhook provider, cocokkan nominal/mata uang/ID, dan proses event secara idempoten.
7. Uji transaksi gagal/kedaluwarsa, refund, webhook duplikat, settlement, dan rekonsiliasi.
8. Minta persetujuan provider dan panduan kepatuhan yang sesuai sebelum menerima dana penjual lain.

Dokumentasi konsep platform: https://docs.xendit.co/docs/xenplatform-overview
